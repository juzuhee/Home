<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="./css/1.css">
    
</head>
<body>
<div class="container">
    <header>
        <?php include "header1.php";?>
    </header>
    
    <section id="container_1">
        <?php include "section1.php";?>
    </section>
    <footer>
        <?php include "footer1.php";?>
    </footer>
</div>  
</body>
</html>