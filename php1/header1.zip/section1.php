<section id="calender_1">
    <div id="calender">2022.11.09</div>
</section>
<section id= "menu1" class="content">
    <p class="border">금전운</p>
    <img class="gift" src="./img/Ellipse66.png">
</section>
<section id= "menu2" class="content">
    <p class="border">학업운</p>
    <img class="gift" src="./img/Ellipse67.png">
</section>
<section id= "menu3" class="content">
    <p class="border">직업운</p>
    <img class="gift" src="./img/Ellipse68.png">
</section>
<section id= "menu4" class="content">
    <p class="border">연애운</p>
    <img class="gift" src="./img/Ellipse69.png">
</section>


