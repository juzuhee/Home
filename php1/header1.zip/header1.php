
<div id="top">
    <div id="top_menu_1">
        <ul>
            <li>오늘의 운세</li>
        </ul>
    </div>

    <div id="top_menu">
        <ul>
            <li>로그아웃</li>
            <li>Q&A</li>
        </ul>
    </div>   
</div>
<nav id = "menu_bar">

        <ul>
            <li><a href="#">오늘의 운세</a></li>
            <li><a href="#">띠운세</a></li>
            <li><a href="#">별자리운세</a></li>
            <li><a href="#">듣고 싶은 말</a></li>
            <li><a href="#">포춘쿠키</a></li>
            <li><a href="#">행운의 아이템</a></li>  
        </ul>
    
</nav>
<div>

</div>

